//
//  ProfileViewController.swift
//  Gettogether
//
//  Created by APEIMANI on 2021-04-19.
//

import UIKit
import Firebase
class ProfileViewController: UIViewController, UITextFieldDelegate{
    
    let StorageRef = Storage.storage().reference()
    var name:String=""
    var phone:String=""
    var email:String=""
    var password:String=""
    var dob:String=""
    var userUid:String=""
    var carName:String=""
    var carNumber:String=""
    var licNumber:String=""
    
    
    @IBOutlet weak var nameTF: UITextField!
    @IBOutlet weak var phoneTF: UITextField!
    @IBOutlet weak var dobTF: UITextField!
    @IBOutlet weak var emailTF: UITextField!

    @IBOutlet weak var carNameTF: UITextField!
    @IBOutlet weak var carNumberTF: UITextField!
    @IBOutlet weak var licTF: UITextField!
    var datePicker : UIDatePicker?
   
    override func viewDidLoad() {
        super.viewDidLoad()
        dobTF.delegate = self
        datePicker = UIDatePicker()
        datePicker?.datePickerMode = .dateAndTime
        
        dobTF.inputView = datePicker
        datePicker?.frame = CGRect(x: 0, y: 50, width: self.view.frame.width, height: 200)
        datePicker?.addTarget(self, action: #selector(ProfileViewController.dateChanged(datePicker:)), for: .valueChanged)
        loadProfileData()
         userUid = Auth.auth().currentUser!.uid
      
    }
    @IBAction func profileUpdate(_ sender: Any) {
   
        let ref = Database.database().reference()
        let userRef = ref.child("Users").child(userUid)
        let values = ["email":emailTF.text!,"Name":nameTF.text!,"Phone":phoneTF.text!,"Date Of Birth":dobTF.text!]
        userRef.updateChildValues(values)
        
        let alert =  UIAlertController(title: "Profile update", message: ("Profile is updated Succesfully"), preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { [self]_ in
        }))
        self.present(alert, animated: true)
    }
    @IBAction func carDetailUpdate(_ sender: Any) {
        let ref = Database.database().reference()
        let userRef = ref.child("Users").child(userUid).child("Car Data")
        let values = ["Car":carNameTF.text!,"Car Number":carNumberTF.text!,"Licence number":licTF.text!]
        userRef.updateChildValues(values)
        
        let alert =  UIAlertController(title: "Updated", message: "Car data changed Succesfully", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { [self]_ in
        }))
        self.present(alert, animated: true)
    }
    @objc func dateChanged(datePicker : UIDatePicker)
     {
     let dateFormatter = DateFormatter()
     dateFormatter.dateFormat = "dd/MM/yyyy"
     dobTF.text = dateFormatter.string(from: datePicker.date)
        view.endEditing(true)
    }
    
    func loadProfileData(){
        userUid=(Auth.auth().currentUser?.uid)!
        print (userUid)
        let ref = Database.database().reference()
        let userRef=ref.child("Users").child(userUid)
        userRef.observeSingleEvent(of: DataEventType.value) { [self] (snapshot) in
            if snapshot.exists() {
                    let value = snapshot.value as? [String: Any]
                print("value",value)
                self.name=value!["Name"]as! String
                self.phone=value!["Phone"]as! String
                self.email=value!["email"]as! String
                if let DOB = value!["Date Of Birth"]as? String
                {
                    self.dob=value!["Date Of Birth"]as! String
                }
                userRef.child("Car Data").observe(DataEventType.value) { (snapshot2) in
                    if snapshot2.exists() {
                        let value2 = snapshot2.value as? [String: Any]
                        self.carName = value2!["Car"] as! String
                        self.carNumber = value2!["Car Number"] as! String
                        self.licNumber = value2!["Licence number"] as!  String
                    }
                
                
                nameTF.text=self.name
                phoneTF.text=self.phone
                dobTF.text=self.dob
                emailTF.text=self.email
                    carNameTF.text=self.carName
                    carNumberTF.text = self.carNumber
                    licTF.text = self.licNumber
                
                    }
        }
        }
        
    }
    @IBAction func logout(_ sender: UIBarButtonItem) {  do{
        print("inside logut")
        try Firebase.Auth.auth().signOut()
        performSegue(withIdentifier: "logout", sender: nil)
        
}
    catch {}
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        segue.destination as?ViewController
    }
 
    
}
