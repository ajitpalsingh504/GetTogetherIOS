//
//  LoginViewController.swift
//  Gettogether
//
//  Created by APEIMANI on 2021-04-02.
//

import UIKit
import Firebase


class LoginViewController: UIViewController {
    
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    @IBOutlet weak var loginBtn: UIButton!
    @IBOutlet weak var errorLabel: UILabel!
    
    struct globalVariable
    {
        static var userid = ""
        static var username = ""
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func loginClicked(_ sender: Any) {
        print("Login clicked")
        
        guard let email=emailTF.text,let password = passwordTF.text  else {
            print("error")
            return
        }
        
        Auth.auth().signIn(withEmail:email , password: password, completion: {result,error in
    
            if error != nil{
                let alert =  UIAlertController(title: "Account not Found", message: "You have to create account", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: {_ in
                }))
                self.present(alert, animated: true)
                return
            }
            else{
                print("Signed In")
//                guard let userID = Auth.auth().currentUser?.uid else { return }
//                let ref = Database.database().reference().child("users")
//                ref.queryOrdered(byChild: userID).queryEqual(toValue: self.emailTF.text).observeSingleEvent(of: DataEventType.value) { (snapshot) in
//                    if snapshot.exists(){
//                        for child in snapshot.children{
//                            let snap = child as!DataSnapshot
//                            let key = snap.key
//                            let value = snap.value as? [String:Any]
//
//                            let username = value?["name"] as! String
//
//                            globalVariable.userid = key
//                            globalVariable.username = username
//                            print (username)
//                            print(key)
                            self.performSegue(withIdentifier: "login", sender: nil)
                        }
//                    }
//                }
//            }
//
       })
}
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    segue.destination as?TabBarViewController
    }
}
