//
//  ConfirmRequestViewController.swift
//  Gettogether
//
//  Created by APEIMANI on 2021-04-21.
//

import UIKit
import Firebase

class ConfirmRequestViewController: UIViewController {
   
    var riderID:String=""
    var riderName:String=""
    var ridePhone:String=""
    var date:String=""
    var price:String=""
    static var source:String=""
    static var destination:String=""
    var userUid:String=""
    var rideID:String=""
    var details:String:""
  
    @IBOutlet weak var riderTF: UITextField!
    @IBOutlet weak var priceTF: UITextField!
    @IBOutlet weak var dateTF: UITextField!
    @IBOutlet weak var sourceDestinationTF: UITextField!
    @IBOutlet weak var detailsTF: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        riderTF.text = riderName+"`s Ride"
        priceTF.text = "$"+price
        dateTF.text = date
        sourceDestinationTF.text = ConfirmBookViewController.source+"  ->  "+ConfirmBookViewController.destination
        detailsTF.text = details
      
      
        
        }
    
    @IBAction func confirmClicked(_ sender: Any) {

        let ref = Database.database().reference()
        let requestRide = ref.child("Users").child(userUid).child("Requests").child("riderID")
        userUid=(Auth.auth().currentUser?.uid)!
        
        print("$$$$$$$$$$$$$$$$$$$$$",driverID)
        print("client id",userUid)
        print("Ride id",rideID)
        
        let values = ["source":ConfirmBookViewController.source,"destination":ConfirmBookViewController.destination,"date":date,"price":price,"riderID":userUid]
        
        requestRide.updateChildValues(values)
        
        
        
        
        
        let alert =  UIAlertController(title: "Ride booked", message: ("Your ride is scheduled to "+date), preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Confirm", style: .default, handler: {_ in self.performSegue(withIdentifier: "confirmhome", sender: nil)
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: {_ in
        }))
        self.present(alert, animated: true)
    
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        segue.destination as?TabBarViewController

    }
    


}
