//
//  PlanRideViewController.swift
//  Gettogether
//
//  Created by APEIMANI on 2021-04-18.
//

import UIKit
import Firebase

class PlanRideViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var sourceTF: UITextField!
    @IBOutlet weak var destinationTF: UITextField!
    @IBOutlet weak var dateTF: UITextField!
    @IBOutlet weak var priceTF: UITextField!
    var datePicker : UIDatePicker?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        dateTF.delegate = self
        datePicker = UIDatePicker()
        datePicker?.datePickerMode = .date
        
        dateTF.inputView = datePicker
        datePicker?.frame = CGRect(x: 0, y: 50, width: self.view.frame.width, height: 200)
        datePicker?.addTarget(self, action: #selector(PlanRideViewController.dateChanged(datePicker:)), for: .valueChanged)
        // Do any additional setup after loading the view.
    }
    @objc func dateChanged(datePicker : UIDatePicker)
     {
     let dateFormatter = DateFormatter()
     dateFormatter.dateFormat = "dd/MM/yyyy"
     dateTF.text = dateFormatter.string(from: datePicker.date)
        view.endEditing(true)
    }
    
    @IBAction func submitTapped(_ sender: Any) {
        guard let source=sourceTF.text,let destination = destinationTF.text,let date = dateTF.text,let price=priceTF.text    else {
            return
        }
        
        guard let userID = Auth.auth().currentUser?.uid else { return }
        let ref = Database.database().reference(fromURL:  "https://gettogether-30dcb-default-rtdb.firebaseio.com/")
        let rideRef = ref.child("Rides").childByAutoId()
        let values = ["source":source,"destination":destination,"date":date,"price":price,"userID":userID]
        rideRef.updateChildValues(values)
        
        
    }
    
}
