//
//  MyRidesViewController.swift
//  Gettogether
//
//  Created by APEIMANI on 2021-04-21.
//

import UIKit
import Firebase

class MyRidesViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    
    var rideList = [ridesData]()
    var riderName:String=""
    var riderPhone:String=""
    var date:String=""
    var price:String=""
    var userid:String=""
    var dateForSearch:String=""
    var source:String=""
    var destination:String=""
    var riderID:String=""
    var rideID:String=""
    var rideDriverID:String=""
    var details:String=""
  
    let ref = Database.database().reference()
  
    @IBOutlet weak var ridesTable: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ridesTable.delegate = self
        ridesTable.dataSource = self
        ridesTable.rowHeight=300
        userid=Auth.auth().currentUser!.uid
        loadRides()
        

        // Do any additional setup after loading the view.
    }
    @IBAction func approveRequest(_ sender: Any) {
        print(riderID)
        print(userid)
        let requestRef = ref.child("Users").child(riderID).child("Requests").child(rideID)
        let driverRef = ref.child("Users").child(userid).child("Requests").child(rideID)
        let values = ["source":source,"destination":destination,"date":date,"price":price,"riderID":userid,"comment":details,"Status":"Approved"]
        requestRef.updateChildValues(values)
        driverRef.updateChildValues(values)
       
//        approveBtn.titleLabel?.text = "Approved"
        
        
        
        let alert =  UIAlertController(title: "Approvel Send", message: ("Ride is on "+date), preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { [self]_ in
        }))
        self.present(alert, animated: true)
    }
    @IBAction func cancelRequest(_ sender: Any) {
        let requestRef = ref.child("Users").child(riderID).child("Requests").child(rideID)
        let values = ["source":"","destination":"","date":"","price":"","riderID":"","comment":"","Status":"Rejected"]

        requestRef.updateChildValues(values)
        
        
        let alert =  UIAlertController(title: "Response Send", message: ("Ride is deleted"+date), preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { [self]_ in
        }))
        self.present(alert, animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        rideList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let rideData = rideList[indexPath.row]
        let cell = ridesTable.dequeueReusableCell(withIdentifier: "ridescell") as? RidesTableViewCell
        let approvecheck=self.ref.child("Users").child(riderID).child("Requests").child(rideID)
        approvecheck.child("Status").observe(DataEventType.value) { (DataSnapshot) in
            if((DataSnapshot.value as! String)=="Approved"){
                cell?.approveBtn.setTitle("Approved", for: .normal)
            }
            
        }
        
        
        cell?.riderName.text = rideData.name
        cell?.riderPhone.text = rideData.phone
        cell?.priceTF!.text = rideData.ridePrice
        cell?.dateTF!.text = rideData.rideDate
        cell?.sourceTF!.text = rideData.rideSource
        cell?.destinationTF!.text = rideData.rideDestination
        return cell!
    }
    func loadRides(){
        let reqRides = ref.child("Users").child(userid).child("Requests")
        
                        reqRides.observeSingleEvent(of: DataEventType.value,with: { (snapshot) in
                            print(snapshot)
                                for child in snapshot.children {
                                    let snap = child as! DataSnapshot
                                    self.rideID=snap.key
                                    let value = snap.value as? [String: Any]
                                    print (self.rideID)
                                        self.date = value!["date"]as! String
                                        self.price = value!["price"] as! String
                                        self.source = value!["source"] as! String
                                        self.destination = value!["destination"] as! String
                                        self.riderID = value!["riderID"] as! String
                                    
                                    
                                        print(self.riderID)
                                    let riderRef = self.ref.child("Users").child(self.riderID)
                                    riderRef.observeSingleEvent(of: DataEventType.value) { (snapshot2) in
                                        let value2 = snapshot2.value as? [String:Any]
                                        self.riderName = value2!["Name"] as! String
                                        self.riderPhone = value2!["Phone"] as! String
                                                        
                                        print(self.riderName)
                                    self.rideList.append(ridesData(name: self.riderName,phone: self.riderPhone, ridePrice: self.price, rideDate:self.date,rideSource:self.source,rideDestination:self.destination,rideDriverID: self.rideDriverID,rideID: self.rideID,riderID: self.riderID))
                                        self.ridesTable.reloadData()
                                    }
                                }
                    },withCancel: nil)
                
            }
}
