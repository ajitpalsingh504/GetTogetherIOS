//
//  ViewController.swift
//  Gettogether
//
//  Created by APEIMANI on 2021-04-01.
//

import UIKit
import Firebase

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
       
        print(Auth.auth().currentUser?.uid ?? "00")
        if Auth.auth().currentUser != nil{
            print ("inside")
            performSegue(withIdentifier: "loggedin", sender: self)
        }
        // Do any additional setup after loading the view.
    }


}

