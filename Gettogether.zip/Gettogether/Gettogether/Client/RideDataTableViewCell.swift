//
//  RideDataTableViewCell.swift
//  Gettogether
//
//  Created by APEIMANI on 2021-04-19.
//

import UIKit

class RideDataTableViewCell: UITableViewCell {
    
     @IBOutlet weak var nameTF: UITextField!
     @IBOutlet weak var phoneTF: UITextField!
     @IBOutlet weak var priceTF: UITextField!
     @IBOutlet weak var dateTF: UITextField!
     @IBOutlet weak var sourceTF: UITextField!
     @IBOutlet weak var destinationTF: UITextField!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
  
}
