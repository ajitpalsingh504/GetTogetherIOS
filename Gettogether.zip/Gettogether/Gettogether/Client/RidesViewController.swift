//
//  RidesViewController.swift
//  Gettogether
//
//  Created by APEIMANI on 2021-04-18.
//

import UIKit
import Firebase

class RidesViewController: UIViewController,UITableViewDelegate,UITableViewDataSource{
    
    var ridesList = [ridesData]()
    var driverName:String=""
    var driverPhone:String=""
    var date:String=""
    var price:String=""
    var userid:String=""
    var dateForSearch:String=""
    var source:String=""
    var destination:String=""
    var driverId:String=""
    var riderID:String=""
    var rideID:String=""
    
    @IBOutlet weak var ridesTable: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        ridesList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let rideData = ridesList[indexPath.row]
        let cell = ridesTable.dequeueReusableCell(withIdentifier: "ridecell") as? RideDataTableViewCell
       // cell?.setValue(item:rideData)
        cell?.nameTF.text = rideData.name
        cell?.phoneTF.text = rideData.phone
        cell?.priceTF.text = rideData.ridePrice
        cell?.dateTF.text = rideData.rideDate
        cell?.sourceTF.text = rideData.rideSource
        cell?.destinationTF.text = rideData.rideDestination
        return cell!
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let ridedata = ridesList[indexPath.row]
        let cVC =  storyboard?.instantiateViewController(identifier: "confirmBook") as? ConfirmBookViewController
        self.navigationController?.pushViewController(cVC!, animated: true)
        cVC?.driverName = ridedata.name
//        cVC?.source = ridedata.rideSource
//        cVC?.destination = ridedata.rideDestination
        cVC?.date = dateForSearch
        cVC?.price = ridedata.ridePrice
        cVC?.driverID = ridedata.rideDriverID
        cVC?.rideID = ridedata.rideID
    }
   


    override func viewDidLoad() {
        super.viewDidLoad()
        ridesTable.rowHeight = 230
        ridesTable.delegate = self
        ridesTable.dataSource = self
        
        let ref = Database.database().reference().child("Rides")
            ref.observeSingleEvent(of: DataEventType.value) { (snapshot) in
                if snapshot.exists() {
                    for child in snapshot.children {
                        let snap = child as! DataSnapshot
                        let value = snap.value as? [String: Any]
                        print(value)
                        self.userid = value!["userID"]as! String
                        
                        print(self.userid)
                        
                        let refuser = Database.database().reference().child("Users").child(self.userid)
                        refuser.observeSingleEvent(of: DataEventType.value,with: { (snapshot2) in
                            print(snapshot2.exists())
                            if snapshot2.exists(){
                                    var value2 = snapshot2.value as? [String: Any]
                                
                                    self.date = value!["date"]as! String
                                if(self.dateForSearch==self.date){
                                    self.driverName = value2!["Name"]as! String
                                    self.driverPhone = value2!["Phone"]as! String
                                    self.price = value!["price"] as! String
                                    self.source = value!["source"] as! String
                                    self.destination = value!["destination"] as! String
                                    self.rideID = snap.key
                                    self.driverId = value!["userID"] as! String
                                    
                                    self.ridesList.append(ridesData(name: self.driverName,phone: self.driverPhone, ridePrice: self.price, rideDate:self.date,rideSource:self.source,rideDestination:self.destination,rideDriverID: self.driverId,rideID: self.rideID, riderID: self.riderID))
                                }
                            else{
                                return
                            }
                                
                            }
                            
                                self.ridesTable.reloadData()
                    },withCancel: nil)
                    }
                    
                }
                
            }
    }
}
