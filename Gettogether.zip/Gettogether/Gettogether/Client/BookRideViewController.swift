//
//  BookRideViewController.swift
//  Gettogether
//
//  Created by APEIMANI on 2021-04-19.
//

import UIKit

class BookRideViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet weak var sourceTF: UITextField!
    @IBOutlet weak var destinationTF: UITextField!
    @IBOutlet weak var dateTF: UITextField!
    
    var datePicker : UIDatePicker?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        dateTF.delegate = self
        datePicker = UIDatePicker()
        datePicker?.datePickerMode = .date
        
        dateTF.inputView = datePicker
        datePicker?.frame = CGRect(x: 0, y: 50, width: self.view.frame.width, height: 200)
        datePicker?.addTarget(self, action: #selector(BookRideViewController.dateChanged(datePicker:)), for: .valueChanged)

        // Do any additional setup after loading the view.
    }
    @objc func dateChanged(datePicker : UIDatePicker)
     {
     let dateFormatter = DateFormatter()
     dateFormatter.dateFormat = "dd/MM/yyyy"
     dateTF.text = dateFormatter.string(from: datePicker.date)
        view.endEditing(true)
    }
    @IBAction func searchRide(_ sender: Any) {
        performSegue(withIdentifier: "search", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let rideVC = segue.destination as?RidesViewController
          
        rideVC?.dateForSearch = dateTF.text!
        ConfirmBookViewController.source = sourceTF.text!
        ConfirmBookViewController.destination = destinationTF.text!
        
    }
    
}
