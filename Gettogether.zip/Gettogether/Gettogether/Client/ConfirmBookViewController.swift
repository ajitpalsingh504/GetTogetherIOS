//
//  ConfirmBookViewController.swift
//  Gettogether
//
//  Created by APEIMANI on 2021-04-19.
//

import UIKit
import Firebase

class ConfirmBookViewController: UIViewController {
    var driverID:String=""
    var driverName:String=""
    var driverPhone:String=""
    var date:String=""
    var price:String=""
    static var source:String=""
    static var destination:String=""
    var userUid:String=""
    var rideID:String=""
    var details:String=""
  
    @IBOutlet weak var driverTF: UITextField!
    @IBOutlet weak var priceTF: UITextField!
    @IBOutlet weak var dateTF: UITextField!
    @IBOutlet weak var sourceDestinationTF: UITextField!
    @IBOutlet weak var detailsTF: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        driverTF.text = driverName+"`s Ride"
        priceTF.text = "$"+price
        dateTF.text = date
        sourceDestinationTF.text = ConfirmBookViewController.source+"  ->  "+ConfirmBookViewController.destination
        
      
      
        
        }
    
    @IBAction func confirmClicked(_ sender: Any) {

        let ref = Database.database().reference()
        let requestRide = ref.child("Users").child(driverID).child("Requests").child(rideID)
        userUid=(Auth.auth().currentUser?.uid)!
        let userRideRef = ref.child("Users").child(userUid).child("Requests").child(rideID)
        
        print("$$$$$$$$$$$$$$$$$$$$$",driverID)
        print("client id",userUid)
        print("Ride id",rideID)
        details=detailsTF.text!

        let values = ["source":ConfirmBookViewController.source,"destination":ConfirmBookViewController.destination,"date":date,"price":price,"riderID":userUid,"comment":details,"Status":"Pending"]
        
        requestRide.updateChildValues(values)
        userRideRef.updateChildValues(values)
        
        
        
        
        let alert =  UIAlertController(title: "Ride booked", message: ("Your ride is scheduled to "+date), preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Confirm", style: .default, handler: {_ in self.performSegue(withIdentifier: "confirmhome", sender: nil)
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: {_ in 
        }))
        self.present(alert, animated: true)
    
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        segue.destination as?TabBarViewController

    }
}
