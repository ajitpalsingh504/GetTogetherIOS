//
//  SignUpViewController.swift
//  Gettogether
//
//  Created by APEIMANI on 2021-04-02.
//

import UIKit
import Firebase

class SignUpViewController: UIViewController {

    @IBOutlet weak var firstNameTF: UITextField!
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    @IBOutlet weak var phoneNumberTF: UITextField!
    @IBOutlet weak var signUpBtn: UIButton!
    @IBOutlet weak var errorLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        

        // Do any additional setup after loading the view.
    }
    
    @IBAction func signUpClicked(_ sender: Any) {
        
        guard let email=emailTF.text,let password = passwordTF.text,let name = firstNameTF.text,let phone=phoneNumberTF.text    else {
            return
        }
        FirebaseAuth.Auth.auth().createUser(withEmail: email, password: password, completion: {result,error in
            guard error == nil else{
                self.errorLabel.text=error?.localizedDescription
                self.errorLabel.alpha = 1
                return
            }
        })
        
        guard let userID = Auth.auth().currentUser?.uid else { return }
        print(userID)
        let ref = Database.database().reference(fromURL:  "https://gettogether-30dcb-default-rtdb.firebaseio.com/")
        let userRef = ref.child("Users").child(userID)
        let values = ["email":email,"Name":name,"Phone":phone]
        userRef.updateChildValues(values)
        let loginViewController = self.storyboard?.instantiateViewController(identifier: "LoginVC") as? LoginViewController
        self.view.window?.rootViewController = loginViewController
        self.view.window?.makeKeyAndVisible()
        
    }
    

}
