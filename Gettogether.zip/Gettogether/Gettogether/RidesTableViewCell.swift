//
//  RidesTableViewCell.swift
//  Gettogether
//
//  Created by APEIMANI on 2021-04-21.
//

import UIKit

class RidesTableViewCell: UITableViewCell {

    @IBOutlet weak var approveBtn: UIButton!
    @IBOutlet weak var riderName: UITextField!
    @IBOutlet weak var riderPhone: UITextField!
    @IBOutlet weak var priceTF: UITextField!
    @IBOutlet weak var dateTF: UITextField!
    @IBOutlet weak var sourceTF: UITextField!
    @IBOutlet weak var destinationTF: UITextField!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
      
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    @IBAction func clickBtn(_ sender: Any) {
        approveBtn.setTitle("Approved", for: .normal)
    }
    @IBAction func cancelRequest(_ sender: Any) {
        
    }
    
}
