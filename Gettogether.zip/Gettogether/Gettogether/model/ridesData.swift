//
//  ridesData.swift
//  Gettogether
//
//  Created by APEIMANI on 2021-04-18.
//

import Foundation
import FirebaseDatabase

struct ridesData{

    let name: String
    let phone: String
    let ridePrice: String
    let rideDate: String
    let rideSource: String
    let rideDestination: String
    let rideDriverID:String
    let rideID:String
    let riderID:String
    
    init(name:String,phone:String,ridePrice:String,rideDate:String,rideSource:String,rideDestination:String,rideDriverID:String,rideID:String,riderID:String) {
        self.name = name
        self.phone = phone
        self.ridePrice = ridePrice
        self.rideDate = rideDate
        self.rideSource = rideSource
        self.rideDestination = rideDestination
        self.rideDriverID = rideDriverID
        self.rideID = rideID
        self.riderID = riderID
    }
    
    
}
