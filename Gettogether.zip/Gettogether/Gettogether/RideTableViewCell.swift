//
//  RideTableViewCell.swift
//  Gettogether
//
//  Created by APEIMANI on 2021-04-18.
//

import UIKit

class RideTableViewCell: UITableViewCell {

    @IBOutlet weak var nameTF: UITextField!
    @IBOutlet weak var phoneTF: UITextField!
    @IBOutlet weak var priceTF: UITextField!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        nameTF.text = "a"
        phoneTF.text = "32"
        priceTF.text = "32"
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
